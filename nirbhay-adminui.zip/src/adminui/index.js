import React from "react";
import "antd/dist/antd.css";
import EditableTable from "./EditableTable";

const AdminUI = () => {
  return (
    <div>
      <EditableTable />
    </div>
  );
};

export default AdminUI;
